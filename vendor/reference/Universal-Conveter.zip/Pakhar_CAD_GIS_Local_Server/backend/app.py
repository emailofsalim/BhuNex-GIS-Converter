from __future__ import annotations

import atexit
import json
import shutil
import tempfile
import uuid
from pathlib import Path

from flask import Flask, Response, jsonify, render_template, request
from werkzeug.utils import secure_filename

from services.dwg_converter import DwgConversionError, convert_dwg_to_dxf

ROOT = Path(__file__).resolve().parents[1]
SERVER_CONFIG = json.loads((ROOT / "config/server-config.json").read_text(encoding="utf-8"))
MINE_PROFILE = json.loads((ROOT / "config/mine-profile.json").read_text(encoding="utf-8"))
TEMP_ROOT = ROOT / "temp"
TEMP_ROOT.mkdir(exist_ok=True)

app = Flask(
    __name__,
    static_folder=str(ROOT / "frontend/static"),
    template_folder=str(ROOT / "frontend/templates"),
)
app.config["MAX_CONTENT_LENGTH"] = int(SERVER_CONFIG["maxUploadMb"]) * 1024 * 1024

ACTIVE_JOBS: set[Path] = set()


def cleanup_job(path: Path) -> None:
    ACTIVE_JOBS.discard(path)
    shutil.rmtree(path, ignore_errors=True)


@atexit.register
def cleanup_all_jobs() -> None:
    for job in list(ACTIVE_JOBS):
        cleanup_job(job)


@app.get("/")
def index():
    return render_template("index.html")


@app.get("/api/profile")
def profile():
    return jsonify(MINE_PROFILE)


@app.get("/api/health")
def health():
    oda_path = Path(SERVER_CONFIG["odaExecutable"])
    return jsonify({
        "status": "ok",
        "dwgConversionReady": oda_path.is_file(),
        "odaExecutable": str(oda_path),
    })


@app.post("/api/convert-dwg")
def convert_dwg():
    upload = request.files.get("file")
    if upload is None or not upload.filename:
        return jsonify({"error": "No DWG file was uploaded."}), 400

    safe_name = secure_filename(upload.filename)
    if not safe_name.lower().endswith(".dwg"):
        return jsonify({"error": "Only DWG files are accepted by this endpoint."}), 400

    job_dir = Path(tempfile.mkdtemp(prefix="dwg_job_", dir=TEMP_ROOT))
    ACTIVE_JOBS.add(job_dir)
    upload_path = job_dir / safe_name

    try:
        upload.save(upload_path)
        if upload_path.stat().st_size < 64:
            return jsonify({"error": "The uploaded DWG is empty or invalid."}), 400

        dxf_path = convert_dwg_to_dxf(
            input_dwg=upload_path,
            work_dir=job_dir,
            executable=Path(SERVER_CONFIG["odaExecutable"]),
            output_version=SERVER_CONFIG["odaOutputVersion"],
            timeout_seconds=int(SERVER_CONFIG["conversionTimeoutSeconds"]),
            recursive=str(SERVER_CONFIG["odaRecursive"]),
            audit=str(SERVER_CONFIG["odaAudit"]),
        )
        dxf_text = dxf_path.read_text(encoding="utf-8", errors="replace")
        response = Response(dxf_text, mimetype="text/plain; charset=utf-8")
        response.headers["X-Original-Filename"] = safe_name
        response.headers["X-Source-Format"] = "DWG"
        response.headers["X-Converted-Filename"] = dxf_path.name
        return response
    except DwgConversionError as error:
        return jsonify({"error": str(error)}), 422
    except Exception as error:
        app.logger.exception("Unexpected conversion error")
        return jsonify({"error": f"Unexpected local conversion error: {error}"}), 500
    finally:
        cleanup_job(job_dir)


@app.errorhandler(413)
def too_large(_error):
    return jsonify({"error": f"File exceeds {SERVER_CONFIG['maxUploadMb']} MB."}), 413


if __name__ == "__main__":
    app.run(
        host=SERVER_CONFIG["host"],
        port=int(SERVER_CONFIG["port"]),
        debug=False,
    )
