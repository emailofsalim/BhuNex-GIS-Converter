from __future__ import annotations

import subprocess
from pathlib import Path


class DwgConversionError(RuntimeError):
    pass


def convert_dwg_to_dxf(
    input_dwg: Path,
    work_dir: Path,
    executable: Path,
    output_version: str,
    timeout_seconds: int,
    recursive: str = "0",
    audit: str = "1",
) -> Path:
    """Convert one DWG to ASCII DXF using the locally installed ODA File Converter."""
    if not executable.is_file():
        raise DwgConversionError(
            f"ODA File Converter was not found at: {executable}. "
            "Update config/server-config.json after installing ODA File Converter."
        )
    if not input_dwg.is_file() or input_dwg.suffix.lower() != ".dwg":
        raise DwgConversionError("The source file is not a valid local DWG path.")

    input_dir = work_dir / "input"
    output_dir = work_dir / "converted"
    input_dir.mkdir(parents=True, exist_ok=True)
    output_dir.mkdir(parents=True, exist_ok=True)

    local_dwg = input_dir / input_dwg.name
    if input_dwg.resolve() != local_dwg.resolve():
        local_dwg.write_bytes(input_dwg.read_bytes())

    command = [
        str(executable),
        str(input_dir),
        str(output_dir),
        output_version,
        "DXF",
        recursive,
        audit,
        "*.dwg",
    ]

    try:
        result = subprocess.run(
            command,
            capture_output=True,
            text=True,
            timeout=timeout_seconds,
            check=False,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
        )
    except subprocess.TimeoutExpired as error:
        raise DwgConversionError(
            f"DWG conversion exceeded {timeout_seconds} seconds."
        ) from error
    except OSError as error:
        raise DwgConversionError(f"ODA could not be started: {error}") from error

    candidates = sorted(output_dir.glob("*.dxf")) + sorted(output_dir.glob("*.DXF"))
    if result.returncode != 0 or not candidates:
        details = (result.stderr or result.stdout or "No converter output").strip()
        raise DwgConversionError(
            f"ODA conversion failed with exit code {result.returncode}. {details[:1000]}"
        )

    output_dxf = max(candidates, key=lambda path: path.stat().st_mtime)
    if output_dxf.stat().st_size < 100:
        raise DwgConversionError("ODA created an empty or invalid DXF file.")

    header = output_dxf.read_bytes()[:256].upper()
    if b"SECTION" not in header:
        raise DwgConversionError("The converted output does not appear to be an ASCII DXF.")

    return output_dxf
