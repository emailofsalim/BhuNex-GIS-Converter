Generated downloads are created by the browser. This folder is reserved for optional future server-side output storage.
