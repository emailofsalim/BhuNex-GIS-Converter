@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo Environment is not installed. Run install.bat first.
  pause
  exit /b 1
)
call ".venv\Scripts\activate.bat"
python run_server.py
if errorlevel 1 pause
