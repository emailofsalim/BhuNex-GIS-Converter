PAKHAR CAD GIS LOCAL SERVER - DXF AND DWG
==========================================

ARCHITECTURE
DXF upload -> browser processing -> GeoJSON, KML, Vertex CSV.
DWG upload -> local Flask server -> ODA DWG-to-DXF conversion -> same browser DXF engine -> GeoJSON, KML, Vertex CSV.

FIRST-TIME SETUP
1. Install Python 3.10 or later and enable Add Python to PATH.
2. Install ODA File Converter on the same Windows computer.
3. Open config/server-config.json and set odaExecutable to the actual ODAFileConverter.exe path.
4. Double-click install.bat.
5. Double-click start_server.bat.
6. The browser opens http://127.0.0.1:8000.

USAGE
- Upload .dxf for direct browser processing.
- Upload .dwg for secure local conversion and then processing.
- Download GeoJSON, KML or vertex-wise CSV.

FIXED CAD LAYERS
Plot: closed LWPOLYLINE/POLYLINE boundaries.
Plot_Text: TEXT/MTEXT plot numbers.

CRS
Default Pakhar profile is EPSG:32645, WGS 84 / UTM zone 45N. Verify against mine control records before official use.

IDENTIFIERS
Mine ID, source filename, source filename hash, source format, plot number, polygon handle and text handle remain separate. No merged feature ID and no plot_id are generated.

DWG CONVERTER CONFIGURATION
The server calls ODA File Converter with source directory, output directory, output version, DXF type, recursive flag, audit flag and *.dwg filter. If the installed ODA edition uses a different executable path, update only config/server-config.json.

PRIVACY AND CLEANUP
All processing runs on localhost. Each DWG uses an isolated temporary folder. Uploaded DWG and converted DXF are deleted after the converted DXF text is returned to the browser.

IMPORTANT LIMITATIONS
- ODA File Converter must be installed separately. Its licensing must be reviewed by the organization.
- Internet access is currently needed for dxf-parser and proj4 CDN scripts. For fully offline use, download approved local copies and change index.html paths.
- BLOCK/INSERT expansion, bulged arcs, holes and geometry repair are not included in this compact proof of concept.
- Test handle preservation from DWG to DXF with representative production drawings.

TROUBLESHOOTING
- If health says DWG not ready, correct odaExecutable.
- If ODA produces no DXF, test the same DWG manually in ODA File Converter.
- If no polygons are found, confirm layer Plot and closed polylines.
- If no labels are found, confirm layer Plot_Text and TEXT/MTEXT entities.
- If KML is misplaced, verify the mine profile CRS and control points.
