import json
import threading
import time
import webbrowser
from pathlib import Path

from waitress import serve

ROOT = Path(__file__).resolve().parent
CONFIG = json.loads((ROOT / "config/server-config.json").read_text(encoding="utf-8"))

import sys
sys.path.insert(0, str(ROOT / "backend"))
from app import app

url = f"http://{CONFIG['host']}:{CONFIG['port']}"
threading.Thread(target=lambda: (time.sleep(1.2), webbrowser.open(url)), daemon=True).start()
print(f"Pakhar CAD GIS local server: {url}")
print("Press Ctrl+C to stop the server.")
serve(app, host=CONFIG["host"], port=int(CONFIG["port"]), threads=4)
