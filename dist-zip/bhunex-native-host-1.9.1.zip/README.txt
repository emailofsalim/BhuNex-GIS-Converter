BhuNex DWG helper
=================

A Chrome or Edge extension cannot execute a file converter. This small program
runs on your own machine, and the extension hands it DWG bytes over Chrome's
native-messaging channel. It drives the ODA File Converter you install
separately, and returns DXF.

IT IS ENTIRELY OPTIONAL. Everything else in BhuNex GIS Converter — every other
import and export format, every QA check, every edit — runs in the browser with
nothing installed. Install this only if you need to read or write DWG.

NOTHING LEAVES YOUR MACHINE. The helper is a local process. It makes no network
request; it reads the bytes the extension passes it, calls a converter already
on your disk, and passes the result back.

BEFORE YOU START
----------------

1. Python 3.9 or newer.
2. ODA File Converter, a free download from the Open Design Alliance. Install
   it and note where it went.

INSTALL
-------

    python install.py

That registers this helper with Chrome and Edge for this extension only.

If ODA File Converter did not land in one of the usual places, open
host-config.json and put its full path in "odaExecutable".

CHECK IT WORKED
---------------

Open the converter workspace. The top bar reads:

    Native engine: ready        the helper answered
    Native engine: unknown      it has not been asked yet
    Native engine: unavailable  it is not installed, or not reachable

If it says unavailable after installing, the usual causes are a Python that is
not on PATH, or an "odaExecutable" path that does not exist.

REMOVING IT
-----------

    python install.py --uninstall

DWG support switches off. Nothing else changes.
